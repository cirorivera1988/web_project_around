Nombre: alrededor de USA

El proyecto es una pagina web interactiva en al que los usuarios pueden visualizar y manipular una coleccion de imagenes de distintos lugares de Estados Unidos. la pagina permite, visualizar una galeria, editar el perfil del usuario, añadir y eliminar fotos y dar me gusta a las fotos

se utilizan las tecniologias conocidas de HTML, CSS BEM Y Responsabilidad, y concenptos basico s de JS

https://github.com/cirorivera1988/web_project_around.git
